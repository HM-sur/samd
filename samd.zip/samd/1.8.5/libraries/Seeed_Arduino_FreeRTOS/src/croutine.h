#ifndef _ARDUINO_CROUTINE_H_
#define _ARDUINO_CROUTINE_H_

#include "../FreeRTOS/Source/include/croutine.h"

#endif //_ARDUINO_CROUTINE_H_
